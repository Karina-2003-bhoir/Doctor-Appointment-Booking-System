from django.urls import path
from . import views

app_name = 'appointments'

urlpatterns = [
    path('', views.home, name='home'),
    path('login/', views.user_login, name='login'),

    path('logout/', views.user_logout, name='logout'),
    path('signup/', views.signup, name='signup'),
    path('doctors/', views.doctor_list, name='doctor_list'),
    path('doctors/<int:pk>/', views.doctor_detail, name='doctor_detail'),
    path('appointment/create/', views.create_appointment, name='create_appointment'),
    path('patient/dashboard/', views.patient_dashboard, name='patient_dashboard'),
    path('doctor/dashboard/', views.doctor_dashboard, name='doctor_dashboard'),
    path('appointment/cancel/<int:pk>/', views.cancel_appointment, name='cancel_appointment'),
]
