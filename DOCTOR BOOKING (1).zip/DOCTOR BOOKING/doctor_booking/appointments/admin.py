# appointments/admin.py
from django.contrib import admin
from .models import UserProfile, DoctorProfile, Appointment

@admin.register(UserProfile)
class UserProfileAdmin(admin.ModelAdmin):
    list_display = ('user', 'role', 'phone')

@admin.register(DoctorProfile)
class DoctorProfileAdmin(admin.ModelAdmin):
    list_display = ('user', 'specialization', 'qualification')

@admin.register(Appointment)
class AppointmentAdmin(admin.ModelAdmin):
    list_display = ('patient', 'doctor', 'appointment_datetime', 'status')
    list_filter = ('status', 'doctor')
    search_fields = ('patient__username', 'doctor__user__username')
