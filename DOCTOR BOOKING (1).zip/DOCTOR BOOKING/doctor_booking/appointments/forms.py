# appointments/forms.py
from django import forms
from django.contrib.auth.models import User
from .models import Appointment, DoctorProfile
from django.contrib.auth.forms import UserCreationForm

class PatientSignUpForm(UserCreationForm):
    email = forms.EmailField(required=True)
    phone = forms.CharField(required=False, max_length=20)

    class Meta:
        model = User
        fields = ('username', 'first_name', 'last_name', 'email', 'password1', 'password2')

class AppointmentForm(forms.ModelForm):
    appointment_datetime = forms.DateTimeField(
        widget=forms.DateTimeInput(attrs={'type': 'datetime-local'}),
        help_text="Select date and time"
    )

    class Meta:
        model = Appointment
        fields = ['doctor', 'appointment_datetime', 'notes']
        widgets = {
            'notes': forms.Textarea(attrs={'rows':3})
        }
