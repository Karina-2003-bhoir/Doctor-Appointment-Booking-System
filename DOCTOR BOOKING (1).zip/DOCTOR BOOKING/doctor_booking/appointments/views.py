# appointments/views.py
from django.shortcuts import render, redirect, get_object_or_404
from .models import DoctorProfile, Appointment, UserProfile
from .forms import AppointmentForm, PatientSignUpForm
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.utils import timezone
from datetime import datetime
import pytz
from django.contrib.auth import authenticate, login, logout





def home(request):
    doctors = DoctorProfile.objects.all()[:6]
    return render(request, 'appointments/home.html', {'doctors': doctors})

def doctor_list(request):
    doctors = DoctorProfile.objects.all()
    return render(request, 'appointments/doctor_list.html', {'doctors': doctors})

def doctor_detail(request, pk):
    doctor = get_object_or_404(DoctorProfile, pk=pk)
    upcoming = doctor.appointments.filter(appointment_datetime__gte=timezone.now(), status='booked')
    return render(request, 'appointments/doctor_detail.html', {'doctor': doctor, 'upcoming': upcoming})

def signup(request):
    if request.method == 'POST':
        form = PatientSignUpForm(request.POST)
        if form.is_valid():
            user = form.save()
            # set role
            user.refresh_from_db()
            user.profile.role = 'patient'
            user.profile.phone = request.POST.get('phone')
            user.save()
            # auto login
            raw_password = form.cleaned_data.get('password1')
            user = authenticate(username=user.username, password=raw_password)
            login(request, user)
            return redirect('appointments:patient_dashboard')
    else:
        form = PatientSignUpForm()
    return render(request, 'appointments/signup.html', {'form': form})



def user_login(request):

    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')

        user = authenticate(request, username=username, password=password)

        if user is not None:
            login(request, user)
            return redirect('appointments:patient_dashboard')
        else:
            messages.error(request, 'Invalid username or password')
            return redirect('appointments:login')

    return render(request, 'appointments/login.html')

@login_required
def user_logout(request):
    logout(request)
    return redirect('appointments:login')


@login_required
def create_appointment(request):
    if request.method == 'POST':
        form = AppointmentForm(request.POST)
        if form.is_valid():
            appointment = form.save(commit=False)
            appointment.patient = request.user
            # Parse incoming datetime-local to aware datetime
            dt = form.cleaned_data['appointment_datetime']
            # If dt is naive, make it timezone-aware using settings timezone
            if timezone.is_naive(dt):
                local_tz = pytz.timezone('Asia/Kolkata')  # change if needed
                dt = local_tz.localize(dt)
            appointment.appointment_datetime = dt
            try:
                appointment.save()
                messages.success(request, 'Appointment booked successfully.')
                return redirect('appointments:patient_dashboard')
            except Exception as e:
                # likely uniqueness/slot clash
                messages.error(request, 'This slot is already taken. Please choose another time.')
    else:
        form = AppointmentForm()
    return render(request, 'appointments/create_appointment.html', {'form': form})

@login_required
def patient_dashboard(request):
    # ensure patient
    if request.user.profile.role != 'patient':
        return redirect('appointments:home')
    appointments = request.user.appointments.all()
    return render(request, 'appointments/patient_dashboard.html', {'appointments': appointments})

@login_required
def doctor_dashboard(request):
    # ensure doctor
    if request.user.profile.role != 'doctor':
        return redirect('appointments:home')
    doctor_profile = request.user.doctor_profile
    appointments = doctor_profile.appointments.filter(appointment_datetime__gte=timezone.now())
    return render(request, 'appointments/doctor_dashboard.html', {'appointments': appointments, 'doctor': doctor_profile})

@login_required
def cancel_appointment(request, pk):
    appt = get_object_or_404(Appointment, pk=pk)
    if request.user == appt.patient or request.user == appt.doctor.user or request.user.is_staff:
        appt.status = 'cancelled'
        appt.save()
        messages.success(request, 'Appointment cancelled.')
    else:
        messages.error(request, 'You are not authorized to cancel this appointment.')
    return redirect('appointments:patient_dashboard')
